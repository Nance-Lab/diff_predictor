import sys


modulename = 'core'
if modulename not in sys.modules:
    import core
    
